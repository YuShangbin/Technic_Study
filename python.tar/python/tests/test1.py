a=1
def fun(a):
    a=2
fun(a)
print a
