class ObjectCreator(object):
    pass
my_object = ObjectCreator()
print my_object
print ObjectCreator
def echo(o):
    print o
echo(ObjectCreator)
ObjectCreatorMirror = ObjectCreator
print ObjectCreatorMirror
