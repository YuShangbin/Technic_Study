print type(1)
print type('1')
class ObjectCreator(object):
    pass
print type(ObjectCreator)
print type(ObjectCreator())
ObjectCreator1 = type('ObjectCreator1', (), {'bar': True})
print ObjectCreator1
print ObjectCreator1()
def echo_bar(self):
    print self.bar
ObjectCreator2 = type('ObjectCreator2', (ObjectCreator1,), {'echo_bar': echo_bar})
print ObjectCreator2
objc2 = ObjectCreator2()
objc2.echo_bar()
