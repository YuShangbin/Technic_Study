a=[]
def fun(a):
    a.append(1)
fun(a)
print a
