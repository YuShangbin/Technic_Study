a = [1, 2, 3]
b = map(lambda x: x*x, a)
print b
